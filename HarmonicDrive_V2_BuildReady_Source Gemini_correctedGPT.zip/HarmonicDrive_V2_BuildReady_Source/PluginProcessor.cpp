#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "CaptureCurves.h"

#include <algorithm>
#include <cmath>

constexpr int HarmonicDriveAudioProcessor::kReportedLatencySamples;

namespace
{
    constexpr float kDriveMin = -5.0f;
    constexpr float kDriveMax =  5.0f;
}

HarmonicDriveAudioProcessor::HarmonicDriveAudioProcessor()
    : AudioProcessor (BusesProperties()
                        .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
                        .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      parameters (*this, nullptr, "PARAMETERS", createParameterLayout()),
      oversampling2x (std::make_unique<Oversampling> (
          2, 1, Oversampling::filterHalfBandPolyphaseIIR, true, true)),
      oversampling4x (std::make_unique<Oversampling> (
          2, 2, Oversampling::filterHalfBandPolyphaseIIR, true, true))
{
    driveParameter = parameters.getRawParameterValue ("drive");
    oversamplingParameter = parameters.getRawParameterValue ("oversampling");
    currentOversamplingMode = juce::jlimit (0, 2, (int) std::round (oversamplingParameter->load()));
}

juce::AudioProcessorValueTreeState::ParameterLayout
HarmonicDriveAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    params.push_back (std::make_unique<juce::AudioParameterFloat> (
        "drive", "Drive",
        juce::NormalisableRange<float> (-5.0f, 5.0f, 0.001f),
        0.0f));

    params.push_back (std::make_unique<juce::AudioParameterChoice> (
        "oversampling", "Oversampling",
        juce::StringArray { "1x", "2x", "4x" },
        2));

    return { params.begin(), params.end() };
}

const juce::String HarmonicDriveAudioProcessor::getName() const
{
    return JucePlugin_Name;
}

void HarmonicDriveAudioProcessor::prepareToPlay (double sampleRate, int samplesPerBlockExpected)
{
    currentSampleRate = juce::jmax (1.0, sampleRate);
    const size_t maxBlockSize = juce::jmax ((size_t) kMaxScratchCapacity, (size_t) samplesPerBlockExpected * 4);

    oversampling2x->initProcessing (maxBlockSize);
    oversampling4x->initProcessing (maxBlockSize);
    oversampling2x->reset();
    oversampling4x->reset();

    // Pre-allocate full capacity upfront to prevent audio-thread reallocations
    driveScratch.assign (maxBlockSize, 0.0f);

    driveSmoother.reset (currentSampleRate, 0.02);
    const float initialDrive = juce::jlimit (kDriveMin, kDriveMax, driveParameter != nullptr ? driveParameter->load() : 0.0f);
    driveSmoother.setCurrentAndTargetValue (initialDrive);

    heatCore.prepareToPlay (currentSampleRate, (int) maxBlockSize);
    heatCore.setCoefficients (1.05436662f, -0.00762319f, -0.08420182f, 0.00511874f, 0.01258004f);

    setLatencySamples (kReportedLatencySamples);
}

void HarmonicDriveAudioProcessor::releaseResources()
{
    oversampling2x->reset();
    oversampling4x->reset();
    heatCore.reset();
}

bool HarmonicDriveAudioProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto& input  = layouts.getMainInputChannelSet();
    const auto& output = layouts.getMainOutputChannelSet();

    if (output != input)
        return false;

    return input == juce::AudioChannelSet::mono()
        || input == juce::AudioChannelSet::stereo();
}

void HarmonicDriveAudioProcessor::processBlock (juce::AudioBuffer<float>& buffer,
                                                 juce::MidiBuffer& midiMessages)
{
    juce::ScopedNoDenormals noDenormals;
    midiMessages.clear();

    const int inputChannels = getTotalNumInputChannels();
    const int outputChannels = getTotalNumOutputChannels();
    const int numSamples = buffer.getNumSamples();

    for (int ch = inputChannels; ch < outputChannels; ++ch)
        buffer.clear (ch, 0, numSamples);

    if (numSamples <= 0)
        return;

    const float targetDrive = juce::jlimit (kDriveMin, kDriveMax, driveParameter != nullptr ? driveParameter->load() : 0.0f);
    driveSmoother.setTargetValue (targetDrive);

    const int requestedMode = juce::jlimit (0, 2,
        (int) std::round (oversamplingParameter != nullptr ? oversamplingParameter->load() : 2.0f));

    if (requestedMode != currentOversamplingMode)
    {
        currentOversamplingMode = requestedMode;
        oversampling2x->reset();
        oversampling4x->reset();
    }

    // Safety guard without reallocation: clamp to Scratch capacity
    const int safeSamples = juce::jmin (numSamples, (int) driveScratch.size());

    for (int i = 0; i < safeSamples; ++i)
    {
        driveScratch[(size_t) i] = juce::jlimit (kDriveMin, kDriveMax, driveSmoother.getNextValue());
    }

    // Prepare JUCE DSP AudioBlock
    juce::dsp::AudioBlock<float> block (buffer);

    // Lock-Free Audio-Thread Oversampling Engine Integration
    if (currentOversamplingMode == 1) // 2x Oversampling
    {
        juce::dsp::AudioBlock<float> upsampledBlock = oversampling2x->processSamplesUp (block);
        processCurveBlock (upsampledBlock, driveScratch.data(), safeSamples, 2);
        oversampling2x->processSamplesDown (block);
    }
    else if (currentOversamplingMode == 2) // 4x Oversampling
    {
        juce::dsp::AudioBlock<float> upsampledBlock = oversampling4x->processSamplesUp (block);
        processCurveBlock (upsampledBlock, driveScratch.data(), safeSamples, 4);
        oversampling4x->processSamplesDown (block);
    }
    else // 1x Native (No Oversampling)
    {
        processCurveBlock (block, driveScratch.data(), safeSamples, 1);
    }
}

void HarmonicDriveAudioProcessor::processCurveBlock (juce::dsp::AudioBlock<float>& block,
                                                      const float* drivePerBaseSample,
                                                      int baseSampleCount,
                                                      int factor) noexcept
{
    // Pass the oversampled audio block to the saturator core
    heatCore.processBlock (block);
}

void HarmonicDriveAudioProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    auto state = parameters.copyState();
    std::unique_ptr<juce::XmlElement> xml (state.createXml());
    copyXmlToBinary (*xml, destData);
}

void HarmonicDriveAudioProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xmlState (getXmlFromBinary (data, sizeInBytes));
    if (xmlState != nullptr && xmlState->hasTagName (parameters.state.getType()))
        parameters.replaceState (juce::ValueTree::fromXml (*xmlState));
}

juce::AudioProcessorEditor* HarmonicDriveAudioProcessor::createEditor()
{
    return new juce::GenericAudioProcessorEditor (*this);
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new HarmonicDriveAudioProcessor();
}
