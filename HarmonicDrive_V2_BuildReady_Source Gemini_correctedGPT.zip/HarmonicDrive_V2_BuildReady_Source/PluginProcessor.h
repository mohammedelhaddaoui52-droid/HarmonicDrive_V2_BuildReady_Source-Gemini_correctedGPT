#pragma once

#include <JuceHeader.h>
#include <juce_dsp/juce_dsp.h>
#include <array>
#include <vector>
#include "HeatSaturatorCore.h"

class HarmonicDriveAudioProcessor final : public juce::AudioProcessor
{
public:
    HarmonicDriveAudioProcessor();
    ~HarmonicDriveAudioProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlockExpected) override;
    void releaseResources() override;
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override;
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState parameters;

    static constexpr int kReportedLatencySamples = 32;
    static constexpr size_t kMaxScratchCapacity = 32768;

private:
    using Oversampling = juce::dsp::Oversampling<float>;

    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

    void processCurveBlock (juce::dsp::AudioBlock<float>& block,
                            const float* drivePerBaseSample,
                            int baseSampleCount,
                            int factor) noexcept;

    std::unique_ptr<Oversampling> oversampling2x;
    std::unique_ptr<Oversampling> oversampling4x;

    std::atomic<float>* driveParameter = nullptr;
    std::atomic<float>* oversamplingParameter = nullptr;
    juce::SmoothedValue<float> driveSmoother;
    std::vector<float> driveScratch;

    double currentSampleRate = 44100.0;
    int currentOversamplingMode = 2; // 0=1x, 1=2x, 2=4x

    HeatSaturatorCore heatCore;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (HarmonicDriveAudioProcessor)
};
