#pragma once

#include <cmath>
#include <algorithm>
#include <juce_dsp/juce_dsp.h>

/**
 * Modern Thread-Safe Waveshaping DSP Engine for Harmonic Drive V2
 */
class HeatSaturatorCore
{
public:
    HeatSaturatorCore() = default;

    void prepareToPlay (double sampleRate, int maxSamplesPerBlock)
    {
        currentSampleRate = (float) sampleRate;
        reset();
    }

    void reset() noexcept
    {
        preFilterState[0] = 0.0f;
        preFilterState[1] = 0.0f;
        postFilterState[0] = 0.0f;
        postFilterState[1] = 0.0f;
    }

    void setCoefficients (float a, float b, float c, float d, float e) noexcept
    {
        h1 = a; h2 = b; h3 = c; h4 = d; h5 = e;
    }

    // Direct waveshaping with extracted hardware curve
    inline float waveshape (float x) const noexcept
    {
        const float x2 = x * x;
        const float x3 = x2 * x;
        const float x4 = x3 * x;
        const float x5 = x4 * x;

        const float y = (h1 * x) + (h2 * x2) + (h3 * x3) + (h4 * x4) + (h5 * x5);
        return std::tanh (y); // Soft-clip ceiling
    }

    // Process juce::dsp::AudioBlock safely without dynamic memory allocation
    void processBlock (juce::dsp::AudioBlock<float>& block) noexcept
    {
        const size_t numChannels = block.getNumChannels();
        const size_t numSamples  = block.getNumSamples();

        for (size_t ch = 0; ch < numChannels; ++ch)
        {
            float* channelData = block.getChannelPointer (ch);
            const size_t stateIdx = (ch < 2) ? ch : 0;

            float preState  = preFilterState[stateIdx];
            float postState = postFilterState[stateIdx];

            for (size_t i = 0; i < numSamples; ++i)
            {
                const float in = channelData[i];

                // 1. High-Pass Pre-Emphasis (Filters DC & extreme low rumble before saturation)
                const float pre = in - preState + 0.995f * preState;
                preState = in;

                // 2. Hardware Polynomial Waveshaping
                const float shaped = waveshape (pre);

                // 3. High-Frequency Roll-off Post-Emphasis
                const float post = 0.75f * shaped + 0.25f * postState;
                postState = post;

                channelData[i] = post;
            }

            preFilterState[stateIdx]  = preState;
            postFilterState[stateIdx] = postState;
        }
    }

private:
    float currentSampleRate = 44100.0f;

    // Extracted coefficients default to Drive 7
    float h1 =  1.05436662f;
    float h2 = -0.00762319f;
    float h3 = -0.08420182f;
    float h4 =  0.00511874f;
    float h5 =  0.01258004f;

    float preFilterState[2]  { 0.0f, 0.0f };
    float postFilterState[2] { 0.0f, 0.0f };
};
