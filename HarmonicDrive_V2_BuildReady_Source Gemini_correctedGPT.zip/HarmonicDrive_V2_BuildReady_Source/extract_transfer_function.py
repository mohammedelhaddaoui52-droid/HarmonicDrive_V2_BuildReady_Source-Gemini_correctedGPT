import numpy as np
from scipy.io import wavfile
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit

# This script compares the dry sweep to the HEAT output to extract the exact saturation curve.

def load_wav(filename):
    sr, data = wavfile.read(filename)
    if data.dtype == np.int32:
        data = data.astype(np.float32) / 2147483648.0
    elif data.dtype == np.int16:
        data = data.astype(np.float32) / 32768.0
    if len(data.shape) > 1:
        data = data.mean(axis=1)
    return sr, data

def extract_transfer_function(dry_file, wet_file):
    print("Loading files...")
    sr_dry, dry = load_wav(dry_file)
    sr_wet, wet = load_wav(wet_file)
    
    # Ensure same length
    min_len = min(len(dry), len(wet))
    dry = dry[:min_len]
    wet = wet[:min_len]
    
    # We focus on the low-frequency part of the sweep (beginning of the file) 
    # to avoid phase/EQ shifts which distort the static transfer curve scatter plot.
    # First 5 seconds usually contains the sub/low frequencies in a 20Hz-20kHz sweep.
    samples_to_use = min(min_len, sr_dry * 5) 
    x = dry[:samples_to_use]
    y = wet[:samples_to_use]
    
    # Define a polynomial function (up to 5th order)
    # y = ax + bx^2 + cx^3 + dx^4 + ex^5
    def poly_func(val, a, b, c, d, e):
        return a*val + b*(val**2) + c*(val**3) + d*(val**4) + e*(val**5)
    
    print("Fitting polynomial curve to extract harmonics...")
    # curve_fit finds the optimal coefficients to transform dry -> wet
    popt, _ = curve_fit(poly_func, x, y)
    
    print("\n--- DERIVED DSP COEFFICIENTS FOR V2 C++ ---")
    print(f"float h1 = {popt[0]:.6f}f; // Linear/Fundamental")
    print(f"float h2 = {popt[1]:.6f}f; // 2nd Harmonic (Asymmetry/Tube)")
    print(f"float h3 = {popt[2]:.6f}f; // 3rd Harmonic (Symmetry/Tape)")
    print(f"float h4 = {popt[3]:.6f}f; // 4th Harmonic")
    print(f"float h5 = {popt[4]:.6f}f; // 5th Harmonic")
    
    # Plotting to verify the fit
    x_plot = np.linspace(min(x), max(x), 1000)
    y_plot = poly_func(x_plot, *popt)
    
    plt.figure(figsize=(10, 6))
    # Subsample scatter plot for performance
    idx = np.random.choice(len(x), size=50000, replace=False)
    plt.scatter(x[idx], y[idx], s=1, alpha=0.05, label='Original HEAT Output')
    plt.plot(x_plot, y_plot, 'r-', linewidth=2, label='Extracted Polynomial V2 Fit')
    plt.title("HEAT Transfer Function (Input vs Output Amplitude)")
    plt.xlabel("Input Amplitude")
    plt.ylabel("Output Amplitude")
    plt.legend()
    plt.grid(True)
    plt.savefig('transfer_function_extracted.png')
    print("\nPlot saved as 'transfer_function_extracted.png'")

if __name__ == "__main__":
    extract_transfer_function('HEAT_dry_sweep_testsignal_44100Hz_mono_32bit.wav', 'HEAT_updated_drive_7.wav')
