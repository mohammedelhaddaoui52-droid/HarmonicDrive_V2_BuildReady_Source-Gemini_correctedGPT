#pragma once

#include <JuceHeader.h>
#include "PluginProcessor.h"

class HarmonicDriveLookAndFeel final : public juce::LookAndFeel_V4
{
public:
    HarmonicDriveLookAndFeel();
    void drawRotarySlider (juce::Graphics&, int x, int y, int width, int height,
                           float sliderPosProportional, float rotaryStartAngle,
                           float rotaryEndAngle, juce::Slider&) override;
};

class HarmonicDriveAudioProcessorEditor final : public juce::AudioProcessorEditor,
                                                 private juce::Timer
{
public:
    explicit HarmonicDriveAudioProcessorEditor (HarmonicDriveAudioProcessor&);
    ~HarmonicDriveAudioProcessorEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;
    juce::String getDriveReadout() const;

    HarmonicDriveAudioProcessor& audioProcessor;
    HarmonicDriveLookAndFeel customLookAndFeel;

    juce::Slider driveSlider;
    juce::Label driveLabel;
    juce::Label driveValueLabel;
    juce::Label oversamplingLabel;
    juce::ComboBox oversamplingBox;

    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> driveAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> oversamplingAttachment;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (HarmonicDriveAudioProcessorEditor)
};
