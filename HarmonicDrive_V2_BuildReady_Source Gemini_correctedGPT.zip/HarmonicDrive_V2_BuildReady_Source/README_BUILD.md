# Harmonic Drive V2 — build-ready source package

This package contains the C++ files from `HarmonicDrive_V2_Final_Source Gemini.zip`, plus the missing CMake/JUCE project configuration and corrected build scripts. The DSP source files have not been edited.

## Dependencies

- CMake 3.22 or newer
- Git and network access to GitHub (the build scripts fetch JUCE 8.0.13)
- macOS: Xcode Command Line Tools
- Windows: Visual Studio 2022 with the C++ desktop build tools

## Build on macOS (Intel VST3)

Run from Terminal:

```bash
./build_macos.sh
```

The script requests an Intel `x86_64` build with a declared minimum macOS deployment target of 10.14. This configuration and the final plugin still need a real compile and binary inspection; the package itself is not evidence that those steps succeeded.

## Build on Windows

Run `build_windows.bat` from a Visual Studio developer command prompt. The script builds the VST3 target with the installed default MSVC architecture.

## Important source-package limitation

The supplied `test_capture_curves.sh` refers to `tests/CaptureCurvesSmokeTest.cpp`, but that test source is not present in the uploaded ZIP. The test script was therefore not included in this build-ready package. No audio comparison or runtime validation is implied by compilation setup alone.
