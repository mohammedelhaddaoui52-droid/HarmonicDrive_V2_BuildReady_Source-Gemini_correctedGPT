#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
JUCE_PATH="${JUCE_DIR:-$ROOT/external/JUCE}"
BUILD_PATH="${BUILD_DIR:-$ROOT/build-macos}"

if ! command -v cmake >/dev/null 2>&1; then
  echo "ERROR: CMake 3.22 or newer is required." >&2
  exit 1
fi
if ! command -v git >/dev/null 2>&1; then
  echo "ERROR: Git is required to fetch JUCE 8.0.13." >&2
  exit 1
fi

if [ ! -f "$JUCE_PATH/CMakeLists.txt" ]; then
  mkdir -p "$(dirname "$JUCE_PATH")"
  git clone --depth 1 --branch 8.0.13 https://github.com/juce-framework/JUCE.git "$JUCE_PATH"
fi

cmake -S "$ROOT" -B "$BUILD_PATH" \
  -DJUCE_DIR="$JUCE_PATH" \
  -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_CXX_STANDARD=17 \
  -DCMAKE_OSX_DEPLOYMENT_TARGET=10.14 \
  -DCMAKE_OSX_ARCHITECTURES=x86_64
cmake --build "$BUILD_PATH" --config Release --target HarmonicDrive_VST3 --parallel 3

PLUGIN="$(find "$BUILD_PATH" -type d -name '*.vst3' -print -quit)"
if [ -z "$PLUGIN" ]; then
  echo "ERROR: Build completed but no .vst3 bundle was found." >&2
  exit 1
fi
printf '\nBuilt bundle: %s\n' "$PLUGIN"
