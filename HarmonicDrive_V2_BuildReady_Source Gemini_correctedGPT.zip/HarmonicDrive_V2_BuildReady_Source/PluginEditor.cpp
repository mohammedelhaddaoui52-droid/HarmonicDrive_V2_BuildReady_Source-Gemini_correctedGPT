#include "PluginEditor.h"

namespace
{
    const juce::Colour kBackground       (0xff101113);
    const juce::Colour kPanelTop         (0xff292b2e);
    const juce::Colour kPanelBottom      (0xff17191b);
    const juce::Colour kBorder           (0xff62666a);
    const juce::Colour kAmber            (0xffd58b21);
    const juce::Colour kAmberBright      (0xffffbd45);
    const juce::Colour kText             (0xfff0f0ed);
    const juce::Colour kMutedText        (0xff9da0a2);
    const juce::Colour kGreen            (0xff8bb94a);
}

HarmonicDriveLookAndFeel::HarmonicDriveLookAndFeel()
{
    setColour (juce::Slider::textBoxTextColourId, kText);
    setColour (juce::ComboBox::backgroundColourId, juce::Colour (0xff202225));
    setColour (juce::ComboBox::textColourId, kText);
    setColour (juce::ComboBox::outlineColourId, kBorder);
    setColour (juce::ComboBox::arrowColourId, kAmberBright);
    setColour (juce::Label::textColourId, kText);
}

void HarmonicDriveLookAndFeel::drawRotarySlider (juce::Graphics& g,
                                                  int x, int y, int width, int height,
                                                  float sliderPosProportional,
                                                  float rotaryStartAngle,
                                                  float rotaryEndAngle,
                                                  juce::Slider&)
{
    const float size = (float) juce::jmin (width, height);
    const float radius = size * 0.335f;
    const float centreX = (float) x + (float) width * 0.5f;
    const float centreY = (float) y + (float) height * 0.47f;
    const float outerRadius = radius + 14.0f;

    // The bezel and subtle shadow give the small control the machined-panel look
    // of classic console controls without copying Avid's logo or artwork.
    g.setColour (juce::Colour (0x99000000));
    g.fillEllipse (centreX - outerRadius, centreY - outerRadius + 3.0f,
                   outerRadius * 2.0f, outerRadius * 2.0f);
    g.setGradientFill (juce::ColourGradient (juce::Colour (0xff777b7f), centreX, centreY - outerRadius,
                                             juce::Colour (0xff26282b), centreX, centreY + outerRadius, false));
    g.fillEllipse (centreX - outerRadius, centreY - outerRadius,
                   outerRadius * 2.0f, outerRadius * 2.0f);
    g.setColour (juce::Colour (0xff111214));
    g.drawEllipse (centreX - outerRadius, centreY - outerRadius,
                   outerRadius * 2.0f, outerRadius * 2.0f, 2.0f);

    const float start = rotaryStartAngle;
    const float end = rotaryEndAngle;
    for (int i = 0; i <= 10; ++i)
    {
        const float p = (float) i / 10.0f;
        const float angle = start + p * (end - start);
        const float inner = outerRadius + 3.0f;
        const float outer = inner + ((i == 0 || i == 5 || i == 10) ? 7.0f : 4.0f);
        const juce::Point<float> a (centreX + std::sin (angle) * inner,
                                    centreY - std::cos (angle) * inner);
        const juce::Point<float> b (centreX + std::sin (angle) * outer,
                                    centreY - std::cos (angle) * outer);
        g.setColour (std::abs (p - sliderPosProportional) < 0.051f ? kAmberBright : juce::Colour (0xff777a7c));
        g.drawLine (a.x, a.y, b.x, b.y, (i == 0 || i == 5 || i == 10) ? 2.0f : 1.2f);
    }

    const float knobRadius = radius;
    const juce::Rectangle<float> knob (centreX - knobRadius, centreY - knobRadius,
                                       knobRadius * 2.0f, knobRadius * 2.0f);
    g.setGradientFill (juce::ColourGradient (juce::Colour (0xff4b4e52), knob.getX(), knob.getY(),
                                             juce::Colour (0xff17191b), knob.getRight(), knob.getBottom(), false));
    g.fillEllipse (knob);
    g.setColour (juce::Colour (0xff0c0d0e));
    g.drawEllipse (knob, 2.0f);

    // Fine inner bevel.
    g.setColour (juce::Colour (0xff686c70));
    g.drawEllipse (knob.reduced (4.0f), 1.0f);

    const float pointerAngle = start + sliderPosProportional * (end - start);
    const float pointerLength = knobRadius * 0.72f;
    const juce::Point<float> pointerEnd (centreX + std::sin (pointerAngle) * pointerLength,
                                         centreY - std::cos (pointerAngle) * pointerLength);
    g.setColour (kAmberBright);
    g.drawLine (centreX, centreY, pointerEnd.x, pointerEnd.y, 3.0f);
    g.setColour (juce::Colour (0xffd7d9da));
    g.fillEllipse (centreX - 3.0f, centreY - 3.0f, 6.0f, 6.0f);
}

HarmonicDriveAudioProcessorEditor::HarmonicDriveAudioProcessorEditor (HarmonicDriveAudioProcessor& p)
    : AudioProcessorEditor (&p), audioProcessor (p)
{
    setLookAndFeel (&customLookAndFeel);
    setSize (420, 318);

    driveSlider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    driveSlider.setRange (-5.0, 5.0, 0.001);
    driveSlider.setSkewFactorFromMidPoint (0.0);
    driveSlider.setRotaryParameters (juce::MathConstants<float>::pi * 1.25f,
                                     juce::MathConstants<float>::pi * 2.75f, true);
    driveSlider.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
    driveSlider.setDoubleClickReturnValue (true, 0.0);
    driveSlider.setName ("Drive");
    addAndMakeVisible (driveSlider);

    driveLabel.setText ("DRIVE", juce::dontSendNotification);
    driveLabel.setJustificationType (juce::Justification::centred);
    driveLabel.setFont (juce::Font (15.0f, juce::Font::bold));
    driveLabel.setColour (juce::Label::textColourId, kText);
    addAndMakeVisible (driveLabel);

    driveValueLabel.setText ("12 O'CLOCK  /  NEUTRAL", juce::dontSendNotification);
    driveValueLabel.setJustificationType (juce::Justification::centred);
    driveValueLabel.setFont (juce::Font (11.5f, juce::Font::bold));
    driveValueLabel.setColour (juce::Label::textColourId, kAmberBright);
    addAndMakeVisible (driveValueLabel);

    oversamplingLabel.setText ("OVERSAMPLING", juce::dontSendNotification);
    oversamplingLabel.setJustificationType (juce::Justification::centredLeft);
    oversamplingLabel.setFont (juce::Font (10.5f, juce::Font::bold));
    oversamplingLabel.setColour (juce::Label::textColourId, kMutedText);
    addAndMakeVisible (oversamplingLabel);

    oversamplingBox.addItem ("1x", 1);
    oversamplingBox.addItem ("2x", 2);
    oversamplingBox.addItem ("4x", 3);
    oversamplingBox.setSelectedId (3, juce::dontSendNotification);
    addAndMakeVisible (oversamplingBox);

    driveAttachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (
        audioProcessor.parameters, "drive", driveSlider);
    oversamplingAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (
        audioProcessor.parameters, "oversampling", oversamplingBox);

    startTimerHz (20);
}

HarmonicDriveAudioProcessorEditor::~HarmonicDriveAudioProcessorEditor()
{
    stopTimer();
    setLookAndFeel (nullptr);
}

void HarmonicDriveAudioProcessorEditor::paint (juce::Graphics& g)
{
    g.fillAll (kBackground);
    auto bounds = getLocalBounds().toFloat().reduced (8.0f);

    g.setGradientFill (juce::ColourGradient (kPanelTop, bounds.getX(), bounds.getY(),
                                             kPanelBottom, bounds.getRight(), bounds.getBottom(), false));
    g.fillRoundedRectangle (bounds, 9.0f);
    g.setColour (kBorder);
    g.drawRoundedRectangle (bounds, 9.0f, 1.4f);

    auto inner = bounds.reduced (8.0f);
    g.setColour (juce::Colour (0xff0c0d0f));
    g.fillRoundedRectangle (inner.removeFromTop (35.0f), 5.0f);

    g.setColour (kText);
    g.setFont (juce::Font (17.0f, juce::Font::bold));
    g.drawText ("HARMONIC DRIVE", 22, 17, getWidth() - 44, 24, juce::Justification::centred);

    g.setColour (kMutedText);
    g.setFont (juce::Font (8.5f, juce::Font::bold));
    g.drawText ("CAPTURE-GUIDED SATURATION", 22, 40, getWidth() - 44, 13, juce::Justification::centred);

    // Warm status strip inspired by the amber HEAT meter.
    juce::Rectangle<float> strip (26.0f, 56.0f, (float) getWidth() - 52.0f, 5.0f);
    g.setColour (juce::Colour (0xff0b0c0d));
    g.fillRoundedRectangle (strip, 2.0f);
    juce::ColourGradient meter (juce::Colour (0xff6e390c), strip.getX(), strip.getY(),
                                kAmberBright, strip.getCentreX(), strip.getCentreY(), false);
    meter.addColour (0.72, kAmber);
    g.setGradientFill (meter);
    g.fillRoundedRectangle (strip.reduced (1.0f), 1.5f);

    g.setColour (kMutedText);
    g.setFont (juce::Font (9.0f));
    g.drawText ("TAPE  <  NEUTRAL  >  TUBE", 50, 239, getWidth() - 100, 15,
                juce::Justification::centred);

    g.setColour (juce::Colour (0xff101113));
    g.drawLine (22.0f, 257.0f, (float) getWidth() - 22.0f, 257.0f, 1.0f);

    g.setColour (kGreen);
    g.fillEllipse ((float) getWidth() - 32.0f, 19.0f, 7.0f, 7.0f);
}

void HarmonicDriveAudioProcessorEditor::resized()
{
    driveLabel.setBounds (110, 64, 200, 22);
    driveSlider.setBounds (93, 76, 234, 154);
    driveValueLabel.setBounds (65, 222, 290, 18);
    oversamplingLabel.setBounds (30, 270, 112, 22);
    oversamplingBox.setBounds (245, 267, 140, 27);
}

void HarmonicDriveAudioProcessorEditor::timerCallback()
{
    const auto newText = getDriveReadout();
    if (driveValueLabel.getText() != newText)
        driveValueLabel.setText (newText, juce::dontSendNotification);
}

juce::String HarmonicDriveAudioProcessorEditor::getDriveReadout() const
{
    const float drive = (float) driveSlider.getValue();
    if (std::abs (drive) < 0.05f)
        return "12 O'CLOCK  /  NEUTRAL";
    if (drive <= -4.95f)
        return "MIN  /  TAPE CHARACTER";
    if (drive >= 4.95f)
        return "MAX  /  TUBE CHARACTER";

    const int index = (int) std::round (drive);
    if (std::abs (drive - (float) index) < 0.05f)
        return "DRIVE " + juce::String (index > 0 ? "+" : "") + juce::String (index);
    return "DRIVE " + juce::String (drive, 1);
}
