@echo off
setlocal
set "ROOT=%~dp0"
set "BUILD_DIR=%BUILD_DIR%"
set "JUCE_DIR=%JUCE_DIR%"
if "%BUILD_DIR%"=="" set "BUILD_DIR=%ROOT%build-windows"
if "%JUCE_DIR%"=="" set "JUCE_DIR=%ROOT%external\JUCE"

where cmake >nul 2>nul
if errorlevel 1 (
  echo ERROR: CMake 3.22 or newer is required.
  exit /b 1
)
where git >nul 2>nul
if errorlevel 1 (
  echo ERROR: Git is required to fetch JUCE 8.0.13.
  exit /b 1
)

if not exist "%JUCE_DIR%\CMakeLists.txt" (
  for %%I in ("%JUCE_DIR%\..") do if not exist "%%~fI" mkdir "%%~fI"
  git clone --depth 1 --branch 8.0.13 https://github.com/juce-framework/JUCE.git "%JUCE_DIR%"
  if errorlevel 1 exit /b 1
)

cmake -S "%ROOT%" -B "%BUILD_DIR%" -DJUCE_DIR="%JUCE_DIR%" -DCMAKE_BUILD_TYPE=Release -DCMAKE_CXX_STANDARD=17
if errorlevel 1 exit /b 1
cmake --build "%BUILD_DIR%" --config Release --target HarmonicDrive_VST3 --parallel
if errorlevel 1 exit /b 1

echo.
echo Build completed. Search "%BUILD_DIR%" for the .vst3 bundle.
endlocal
